{
	"file_path": "C:\\Users\\chupi\\AppData\\Local\\Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\LocalState\\games\\com.mojang\\development_behavior_packs\\ModernDecoration\\scripts\\client\\client.js",
	"file_type": "script",
	"format_version": 0,
	"file_uuid": "2a117211_628f_44ae_a049_170609fa1b2b",
	"file_version": 5,
	"cache_content": "let system = client.registerSystem(0,0);\n\nsystem.initialize = function() {\n};\n\nlet firstTick = true;\nlet tickCount = 0;\nsystem.update = function () {\n    tickCount++;\n    if (firstTick) {\n        firstTick = false;\n        system.broadcastEvent(\"minecraft:display_chat_event\", \"Hello bro\");\n    }\n\n    if (tickCount%20==0) {\n        system.broadcastEvent(\"minecraft:execute_command\", \"/setblock ~ ~-1 ~ stone\");\n    }\n};"
}